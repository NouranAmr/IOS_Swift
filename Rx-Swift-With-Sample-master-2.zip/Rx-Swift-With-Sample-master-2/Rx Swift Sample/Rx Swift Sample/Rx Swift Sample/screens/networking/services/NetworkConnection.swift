//
//  NetworkProtocol.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
import RxAlamofire
import RxSwift

class NetworkConnection: NetworkDelegate {
    
    
    func setDelegete(delegete: MyTableViewPresenterDelegate) {
        countryPresenter = delegete
    }
    
    var countryPresenter : MyTableViewPresenterDelegate?
    var disposeBag = DisposeBag()

    func connect(url: String) {
    
    
        RxAlamofire.requestData(.get, url)
            .debug()
            .subscribe(onNext: {[weak self](r, json) in
                if (json != nil) {
                    do{
                        let currencyConverter = try JSONDecoder().decode(CountryApi.self, from: json)
                       //print(currencyConverter)
                       
                        print(currencyConverter.rates.keys)
                        self?.countryPresenter?.recieveCurrencyDict(currency: currencyConverter )
                   	
                    }
                    catch let error
                    {
                        print(error.localizedDescription)
                        
                    }
                }
                   
            })
            .disposed(by: disposeBag)
     
    }
}
    
