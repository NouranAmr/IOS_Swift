//
//  CountryPresenter.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
class CountryPresenter : MyTableViewPresenterDelegate {
  
    
    var myTableVCDelegate : MyTableViewControllerDelegate?
    var networkConnection : NetworkDelegate = NetworkConnection()
    
    init() {
        
        networkConnection.setDelegete(delegete: self)
        
    }
    func setDelegete(delegete: MyTableViewControllerDelegate) {
        myTableVCDelegate = delegete
    }
     func recieveCurrencyDict(currency : CountryApi)
     {
        currencyArrays(country: Array(currency.rates.keys) , currency: Array(currency.rates.values))
     }
    func currencyArrays(country: [String], currency: [Double]) {
        myTableVCDelegate?.setTableView(country: country, currency: currency)
    }
    
    
    func startConnection(url: String) {
        networkConnection.connect(url: url)
    }
}
