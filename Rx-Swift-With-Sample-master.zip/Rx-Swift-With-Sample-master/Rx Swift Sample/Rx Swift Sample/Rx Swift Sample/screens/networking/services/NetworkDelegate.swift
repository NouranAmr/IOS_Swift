//
//  NetworkDelegate.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
protocol NetworkDelegate {
     func connect (url: String)
}
