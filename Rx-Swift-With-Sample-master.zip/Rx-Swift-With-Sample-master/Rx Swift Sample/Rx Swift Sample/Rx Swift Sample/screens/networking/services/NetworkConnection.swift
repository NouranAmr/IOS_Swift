//
//  NetworkProtocol.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
import RxAlamofire
import RxSwift

class NetworkConnection: NetworkDelegate {
    func connect(url: String) {
        
        var disposeBag = DisposeBag()
        RxAlamofire.requestJSON(.get, url)
            .debug()
            .subscribe(onNext: { (r, json) in
                if let dict = json as? [String: AnyObject] {
                    let valDict = dict["rates"] as! Dictionary<String, AnyObject>
                    
                }
                   
            })
            .disposed(by: disposeBag)
     
    }
    

}
