//
//  NetworkProtocol.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
import RxAlamofire
import RxSwift

class NetworkConnection: NetworkDelegate {
    var countryPresenter : MyTableViewPresenterDelegate = CountryPresenter ()
    func connect(url: String) {
        
        var disposeBag = DisposeBag()
        RxAlamofire.requestJSON(.get, url)
            .debug()
            .subscribe(onNext: { (r, json) in
                if let dict = json as? [String: Any] {
                    let valDict = dict["rates"] as! [String:Any]?
                    print(valDict)
                    self.countryPresenter.recieveCurrencyDict(currency: valDict! )
                }
                   
            })
            .disposed(by: disposeBag)
     
    }
     func setDelegete(delegete: MyTableViewPresenterDelegate)
     {
        countryPresenter = delegete
    }
    
    

}
