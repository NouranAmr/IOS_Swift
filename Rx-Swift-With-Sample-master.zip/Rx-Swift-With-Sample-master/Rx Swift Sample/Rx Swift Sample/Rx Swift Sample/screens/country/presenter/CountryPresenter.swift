//
//  CountryPresenter.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
class CountryPresenter : MyTableViewPresenterDelegate {
    
    var myTableVCDelegate : MyTableViewControllerDelegate?
    var networkConnection : NetworkDelegate = NetworkConnection()
    
    init() {
        
        networkConnection.setDelegete(delegete: self)
        
    }
     func recieveCurrencyDict(currency : [String:Any] )
     {
        myTableVCDelegate?.setTableView(currency: currency)
     }
    func setDelegete(delegete: MyTableViewControllerDelegate) {
        myTableVCDelegate = delegete
    }
    func startConnection(url: String) {
        networkConnection.connect(url: url)
    }
}
