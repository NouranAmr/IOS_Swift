//
//  MyCollectionViewCell.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab - 9 on 5/26/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var nameLabel: UILabel!
}
