//
//  SecondViewController.swift
//  Rx Swift Sample
//
//  Created by JETS Mobile Lab-3 on 5/27/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class SecondViewController: UIViewController {

    @IBOutlet var throttleBtn: UIButton!
    @IBOutlet var debounceBtn: UIButton!
    
    @IBOutlet var searchLabel: UILabel!
    @IBOutlet var searchTextField: UITextField!
    var diposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()

        throttleBtn.rx.tap.throttle(2,scheduler: MainScheduler.asyncInstance)
            .subscribe(onNext:{ (_) in
                print("tap_throttle")
            }).disposed(by: diposeBag)
        
        debounceBtn.rx.tap.debounce(3,scheduler: MainScheduler.asyncInstance)
            .subscribe(onNext : { (_) in
                print("tap_debounce")
            }).disposed(by: diposeBag)
        
        var search = searchTextField.rx.controlEvent(.editingChanged).asObservable()
            .subscribe(onNext: {
                (t) in
                self.searchLabel.text?.append(self.searchTextField.text!)
            }).disposed(by : diposeBag)
        
        
    }
    


}
